#!/bin/bash

TEST_PHP_EXECUTABLE=/local/php/bin/php /local/php/bin/php /local/php.src/php-4.4.7/run-tests.php -m tests
