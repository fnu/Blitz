<?php
include('common.inc');

//$body = "start = {{\$start }}\n{{ BEGIN test }}name = {{ \$name }}\n{{ END }}";
$body = "{{ BEGIN test }}name = {{ \$name }} {{ END }}";
$T = new Blitz();
$T->load($body);
//$T->set(array("name" => "john")); // this will set name to root context and it will not be seen
//$T->iterate("/test");

//$T->context("/");
//$T->set(array("start" => "done"));

echo $T->parse(
    array(
        'name' => 'john',
        'test' => array(
            0 => array(
                'var' => 'value'
            )
        )
    )
);

?>
