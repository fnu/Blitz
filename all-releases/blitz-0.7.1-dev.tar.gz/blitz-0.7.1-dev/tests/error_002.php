<?php

include('common.inc');
$T = new Blitz('error_002.tpl');

var_dump($T);

echo "Done\n";
?>
