<?php

include('common.inc');
$T = new Blitz('error_001.tpl');

var_dump($T);

echo "Done\n";
?>
