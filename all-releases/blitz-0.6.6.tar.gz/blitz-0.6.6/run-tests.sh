#!/bin/bash

TEST_PHP_EXECUTABLE=/local/php/bin/php /local/php/bin/php /local/build/php/4_4_8/run-tests.php -m tests
