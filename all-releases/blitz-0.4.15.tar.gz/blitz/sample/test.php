<?

$T = new Blitz('test.tpl');
echo $T->parse();

?>
