<?

error_reporting(E_ALL);
ini_set('display_errors', 'On');

$body = <<<BODY
    {{ PHP::date("Y/m/d H:i") }}
    self-call: {{ this::doSomething() }}
    php-call: {{ php::doSomething() }}
    self+php call: {{ doSomething() }}
    self+php call: {{ doSomething2() }}

BODY;

function doSomething() {
    return 'PHP :: did comething';
}

class View extends Blitz {
    function doSomething() {
        return 'SELF :: did something';
    }

    function __call($a, $b) {
        return '__call handler: '.var_export($a, true).', '.str_replace(array("\n","\r"), "", var_export($b, true));
    }
}

$T = new View();
$T->load($body);
$T->display();

?>
