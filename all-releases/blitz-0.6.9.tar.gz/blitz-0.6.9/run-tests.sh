#!/bin/bash

TEST_PHP_EXECUTABLE=/usr/local/bin/php /usr/local/bin/php /distr/php-4.4.7/run-tests.php -m tests
