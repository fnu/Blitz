<?

$T = new Blitz('ex2A.tpl');
echo $T->parse();
echo "\n";

?>
