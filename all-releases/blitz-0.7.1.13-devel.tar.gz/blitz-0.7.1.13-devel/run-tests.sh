#!/bin/bash

TEST_PHP_EXECUTABLE=/local/php/bin/php /local/php/bin/php ./run-tests.php tests
